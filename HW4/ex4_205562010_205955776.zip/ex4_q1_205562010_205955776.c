#define MAX_NUM_PRODUCTS 20
#define MAX_PRODUCT_NAME_LENGTH 20
#define MAX_CATEGORY_LENGTH 10
#define BARCODE_LENGTH 12
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

const char * main_interface = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"\
"Welcome to CORONA market!\n"\
"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"\
"Manage market menu:\n"\
"	1. Add product\n"\
"	2. Remove product\n"\
"	3. Check which products are expired\n"\
"	4. Print all the products\n"\
"	5. Update product\n"\
"	6. EXIT SYSTEM\n"\
"Please choose operation [1-6]:";

//operation 1 constant strings

const char *  adding_product_barcode = "Please enter product barcode:";
const char * barcode_already_exist = "This product already exist, please enter the number of products to add: ";
const char * too_much_products = "Can't add more products, not enough space";
const char * adding_product_name = "Please enter product name:";
const char * adding_product_category = "Please enter product category:";
const char * adding_product_number = "Please enter number of products to add:";
const char * adding_product_price = "Please enter the price of the product:";
const char * adding_product_date = "Please enter expiration date of the product[dd/mm/yy]:";

//operation 2 constant strings
const char * store_empty = "The store is empty!";
const char * delete_barcode = "Please enter product barcode you want to delete:";
const char * delete_barcode_cant_find = "Couldn't find the product barcode, try again...\n";
const char * delete_barcode_succeed = "The product deleted successfully!";


//operation 3 constant strings
const char * expired_date_check = "What date you want to check[dd/mm/yy]:";
const char * expired_products = "~~~~~~~~~~~~~~~Expired Products~~~~~~~~~~~~~~~";
const char * expired_product_name = "\nProduct name: ";
const char * expired_product_barcode = "\nProduct barcode: ";
const char * expired_product_date = "\nProduct expiration date: ";


//operation 4 constant strings
const char * print_no_products = "No products in the store!";
const char * print_all = "~~~~~~~~~~~~~~~All Products~~~~~~~~~~~~~~~";
const char * print_products = "\n----------";
const char * print_product_name = "\nProduct name: ";
const char * print_product_barcode = "\nProduct barcode: ";
const char * print_product_category = "\nProduct category: ";
const char * print_product_number = "\nProduct available quantity: ";
const char * print_product_price = "\nProduct price: ";
const char * print_product_expireDate = "\nProduct expiration date: ";
const char * print_total_number = "\nTotal number of products: ";

//operation 5 constant strings
const char * update_barcode = "Please enter product barcode you want to update:";
const char * update_barcode_notFound = "Couldn't find the product barcode, try again...\n";
const char * update_interface_string = ("What do you want to update?\n"\
	"	1. Product name\n"\
	"	2. Product category\n"\
	"	3. Product quantity\n"\
	"	4. Product price\n"\
	"	5. Product expiration date\n"\
	"Please choose operation [1-5]:");
const char * update_product_name = "Please enter new product name:";
const char * update_product_category = "Please enter new product category:";
const char * update_product_number = "Please enter new product quantity:";
const char * update_product_price = "Please enter new product price:";
const char * update_product_date = "Please enter new product expiration date[dd/mm/yy]:";

//operation 6 constant strings
const char * exit_program = "exit...";

typedef struct date
{
	int year;
	int month;
	int day;
} date;

typedef struct product
{
	char * product_name;
	char * product_category;
	char * barcode;
	int available;
	double price;
	date * expire_date;
} product;

typedef struct super_market
{
	product ** product_list;
	int number_of_products;
} super_market;

int compare_strings(char *s1, char *s2) /*Inputs: (*s1,*s2 = pointers to strings)
										Return parameter:(1 - not equal, 0 - equal)
										Function functionality: check if two strings are equal.*/
{
	int i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		if (s1[i] != s2[i])
			return 0;
		i++;
	}
	return 1;
}

int check_loc(int loc) /*Inputs: (loc = any pointer(hex value) who was assign to dynamic memory)
					   Return parameter:(1 - fail, 0 - success)
					   Function functionality: check if dynamic memory assignment succeed,
					   if not print error message and return 1 - which means the assignment failed*/
{
	if (loc == NULL)
	{
		printf("dynamic memory assignment error");
		return 1;
	}
	return 0;
}

int check_barcode(super_market* store, char* p_barcode) /*Inputs: (*store - pointer to the store to check barcode in,
														p_barcode - pointer to the barcode we have to find)
														Return parameter:(i - produt index in **product_list,
														(-1) - there is no product with the same barcode)
														Function functionality: return index of product with p_barcode in **product_list of a given store,
														if such product doesn't exist return (-1)*/
{
	for (int i = 0; i < MAX_NUM_PRODUCTS; i++)
	{
		if (store->product_list[i] == 0) continue;
		if (compare_strings(store->product_list[i]->barcode, p_barcode))
			return i;
	}
	return -1;
}

int add_product(super_market *store) /*Inputs: (*store - pointer to the store to add product)
									 return parameter:(0 - success, 1 - dynamic memory error)
									 Function functionality: adding product to **product_list due to user inputs,
									 using dynamic memory assignments. assigns pointers and values in product pointer *p
									 and assign *p in empty pointer in **product_list*/
{
	int i, quantity;
	char *p_barcode = NULL;
	if (check_loc(p_barcode = (char*)malloc(BARCODE_LENGTH + 1))) return 1;
	printf(adding_product_barcode);
	scanf("%s", p_barcode);
	i = check_barcode(store, p_barcode);
	if (i >= 0)
	{
		printf(barcode_already_exist);
		scanf("%d", &quantity);
		store->product_list[i]->available += quantity;
		printf("Additional %d products of %s added", quantity, store->product_list[i]->product_name);
		free(p_barcode);
	}
	else
	{
		if (store->number_of_products >= MAX_NUM_PRODUCTS)
		{
			printf(too_much_products);
			free(p_barcode);
			return 0;
		}
		product* p = NULL;
		if (check_loc(p = (product*)malloc(sizeof(product))))
		{
			free(p_barcode);
			return 1;
		}
		if (check_loc(p->product_name = (char*)malloc(MAX_PRODUCT_NAME_LENGTH + 1)))
		{
			free(p_barcode);
			free(p);
			return 1;
		}
		if (check_loc(p->product_category = (char*)malloc(MAX_PRODUCT_NAME_LENGTH + 1)))
		{
			free(p_barcode);
			free(p->product_name);
			free(p);
			return 1;
		}
		if (check_loc(p->expire_date = (date*)malloc(sizeof(date))))
		{
			free(p_barcode);
			free(p->product_name);
			free(p->product_category);
			free(p);
			return 1;
		}
		p->barcode = p_barcode;
		printf(adding_product_name);
		scanf("\n%[^\n]s", p->product_name);
		printf(adding_product_category);
		scanf("\n%[^\n]s", p->product_category);
		printf(adding_product_number);
		scanf("%d", &p->available);
		printf(adding_product_price);
		scanf("%lf", &p->price);
		printf(adding_product_date);
		scanf("%d/%d/%d", &p->expire_date->day, &p->expire_date->month, &p->expire_date->year);
		i = 0;
		while (store->product_list[i] != 0) i++;
		store->product_list[i] = p;
		store->number_of_products++;
		printf("The product %s -barcode:%s ,added successfully", p->product_name, p->barcode);
	}
	return 0;
}

void product_del(super_market* store, int product_ind) /*Inputs: (*store - pointer to the store to delete product in,
													   product_ ind - index of the product to delete in **product_list)
													   return parameter:(None)
													   Function functionality: delete the product which product_list[product_ind] point to,
													   free all the dynamic memory assignments of this product and product_list[product_list]=0*/
{
	store->number_of_products--;
	free(store->product_list[product_ind]->expire_date);
	free(store->product_list[product_ind]->product_category);
	free(store->product_list[product_ind]->product_name);
	free(store->product_list[product_ind]->barcode);
	free(store->product_list[product_ind]);
	store->product_list[product_ind] = 0;
}

int remove_product(super_market* store) /*Inputs: (*store - pointer to the store to remove product in)
										return parameter:(0 - success, 1 - dynamic memory error)
										Function functionality: get barcode from the user and delete the product which has this barcode.
										first, find the index of the asked product,then use product_del to remove the product*/
{
	if (store->number_of_products == 0)
	{
		printf(store_empty);
		return 0;
	}
	int product_ind = -1;
	char *d_barcode = NULL;
	if (check_loc(d_barcode = (char*)malloc(BARCODE_LENGTH + 1))) return 1;
	while (product_ind == -1)
	{
		printf(delete_barcode);
		scanf("%s", d_barcode);
		product_ind = check_barcode(store, d_barcode);
		if (product_ind == -1)
			printf(delete_barcode_cant_find);
	}
	free(d_barcode);
	product_del(store, product_ind);
	printf(delete_barcode_succeed);
	return 0;
}

int is_later(date date1, date date2) /*Inputs: (*store - pointer to the store to delete product)
									 return parameter:(0 - date1.day >= date2.day, 1 - date1.day < date2.day)
									 Function functionality : return 0 if date1 is later than or equal to date2, return 1 else
									 compare the parameters by the order: year, month, day*/
{
	if (date1.year < date2.year)
		return 1;
	else if (date1.year == date2.year)
		if (date1.month < date2.month)
			return 1;
		else if (date1.month == date2.month)
			return (date1.day < date2.day);
	return 0;
}

void print_expired(super_market* store) /*Inputs: (*store - pointer to the store contains the expired date products to print)
										return parameter:(None)
										Function functionality: get date from the user and print all products in **product_list
										that has expired date later than the given date. use is_later to compare dates.*/
{
	date check_date;
	int i;
	printf(expired_date_check);
	scanf("%d/%d/%d", &check_date.day, &check_date.month, &check_date.year);
	printf(expired_products);
	for (i = 0; i < MAX_NUM_PRODUCTS; i++)
	{
		if (store->product_list[i] == 0) continue;
		if (is_later(*store->product_list[i]->expire_date, check_date))
		{
			printf(expired_product_name);
			printf("%s", store->product_list[i]->product_name);
			printf(expired_product_barcode);
			printf("%s", store->product_list[i]->barcode);
			printf(print_product_expireDate);
			printf("%d/%d/%d", store->product_list[i]->expire_date->day, store->product_list[i]->expire_date->month, store->product_list[i]->expire_date->year);
		}
	}
}

int print_all_products(super_market* store) /*Inputs: (*store - pointer to the store to print products)
											return parameter:(0)
											Function functionality: print all the products in the store*/
{
	if (store->number_of_products == 0)
	{
		printf(print_no_products);
		return 0;
	}
	printf(print_all);
	for (int i = 0; i < MAX_NUM_PRODUCTS; i++)
	{
		if (store->product_list[i] != 0)
		{
			printf(print_products);
			printf(print_product_name);
			printf(store->product_list[i]->product_name);
			printf(print_product_barcode);
			printf(store->product_list[i]->barcode);
			printf(print_product_category);
			printf(store->product_list[i]->product_category);
			printf(print_product_number);
			printf("%d", store->product_list[i]->available);
			printf(print_product_price);
			printf("%g", store->product_list[i]->price);
			printf(print_product_expireDate);
			printf("%d/%d/%d", store->product_list[i]->expire_date->day, store->product_list[i]->expire_date->month, store->product_list[i]->expire_date->year);
		}
	}
	printf(print_total_number);
	printf("%d", store->number_of_products);
	return 0;
}

int update_product(super_market* store) /*Inputs: (*store - pointer to the store to delete product)
										return parameter:(0 - success, 1 - dynamic memory error or no products in the store)
										Function functionality: asking from the user for a product barcode which the user want to update.
										the fanction offers to the user 5 options for updating: name,category,quantity,price and expired_date */
{
	int product_ind = -1, option, quantity;
	char *d_barcode = NULL;
	if (check_loc(d_barcode = (char*)malloc(BARCODE_LENGTH + 1))) return 1;
	if (store->number_of_products == 0)
	{
		printf(print_no_products);
		return 0;
	}
	while (product_ind == -1)
	{
		printf(update_barcode);
		scanf("%s", d_barcode);
		product_ind = check_barcode(store, d_barcode);
		if (product_ind == -1)
			printf(update_barcode_notFound);
	}
	printf(update_interface_string);
	scanf("%d", &option);
	switch (option)
	{
	case 1:
		printf(update_product_name);
		scanf("\n%[^\n]s", store->product_list[product_ind]->product_name);
		break;
	case 2:
		printf(update_product_category);
		scanf("\n%[^\n]s", store->product_list[product_ind]->product_category);
		break;
	case 3:
		printf(update_product_number);
		scanf("%d", &store->product_list[product_ind]->available);
		break;
	case 4:
		printf(update_product_price);
		scanf("%lf", &store->product_list[product_ind]->price);
		break;
	case 5:
		printf(update_product_date);
		scanf("%d/%d/%d", &store->product_list[product_ind]->expire_date->day, &store->product_list[product_ind]->expire_date->month, &store->product_list[product_ind]->expire_date->year);
		break;
	}
	free(d_barcode);
	return 0;
}


void exit_system(super_market* store) /*Inputs: (*store - pointer to the store to delete)
									  return parameter:(None)
									  Function functionality: free all the dynamic memory store used*/
{
	for (int i = 0; i < MAX_NUM_PRODUCTS; i++)
	{
		if (store->product_list[i] != 0)
			product_del(store, i);
	}
	free(store->product_list);
	free(store);
	printf(exit_program);
}

int main() /*Inputs: (*store - pointer to the store to print products)
		   return parameter:(0 - success, 1 - error (dynamic memory assignment failed))
		   Function functionality: create super_market instance "Corona", print menu and call functions according to user choice
		   in loop until user choose to exit.*/
{
	int option = 0;
	super_market* Corona = NULL;
	if (check_loc(Corona = (super_market*)malloc(sizeof(super_market)))) return 1;
	Corona->number_of_products = 0;
	if (check_loc(Corona->product_list = (product**)calloc(MAX_NUM_PRODUCTS, sizeof(product*))))
	{
		free(Corona);
		return 1;
	}
	while (option != 6)
	{
		printf(main_interface);
		scanf("%d", &option);
		switch (option)
		{
		case 1:
			add_product(Corona);
			break;
		case 2:
			remove_product(Corona);
			break;
		case 3:
			print_expired(Corona);
			break;
		case 4:
			print_all_products(Corona);
			break;
		case 5:
			update_product(Corona);
			break;
		case 6:
			exit_system(Corona);
			return 0;
			break;
		}
		printf("\n");
	}
	return 0;
}